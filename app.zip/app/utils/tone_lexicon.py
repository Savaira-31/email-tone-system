TONE_DEFINITIONS = {
    "formal": {"description": "Professional, respectful", "openings": ["Dear {recipient},"], "closings": ["Sincerely,", "Best regards,"], "transition_words": ["furthermore", "moreover"], "avoid_words": ["hey", "gonna"], "emoji_allowed": False},
    "friendly": {"description": "Warm, approachable", "openings": ["Hi {recipient}!", "Hey {recipient},"], "closings": ["Cheers,", "Best,"], "transition_words": ["also", "plus"], "avoid_words": ["hereby", "pursuant"], "emoji_allowed": True},
    "urgent": {"description": "Time-sensitive, direct", "openings": ["URGENT: {recipient},"], "closings": ["Awaiting urgent response."], "transition_words": ["immediately", "urgently"], "avoid_words": ["whenever"], "emoji_allowed": False},
    "apologetic": {"description": "Sincere", "openings": ["I sincerely apologize,"], "closings": ["Thank you for understanding."], "transition_words": ["unfortunately", "regrettably"], "avoid_words": ["whatever"], "emoji_allowed": False},
    "persuasive": {"description": "Convincing", "openings": ["Imagine if we could..."], "closings": ["I'm confident you'll see the value."], "transition_words": ["imagine", "opportunity"], "avoid_words": ["maybe"], "emoji_allowed": False},
    "neutral": {"description": "Balanced", "openings": ["Hello {recipient},"], "closings": ["Regards,"], "transition_words": ["also", "however"], "avoid_words": [], "emoji_allowed": False}
}
