from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    GROQ_API_KEY: str = ""
    MODEL_NAME: str = "llama-3.1-8b-instant"
    MAX_TOKENS: int = 1000
    TEMPERATURE: float = 0.7
    class Config:
        env_file = ".env"

settings = Settings()