Groq = None
# Import groq lazily to avoid top-level import errors in environments
# where the package isn't installed (helps linters and optional deps).

from typing import TYPE_CHECKING
from app.config import settings
from app.models.schemas import EmailInput, GeneratedEmail, ToneType, BatchEmailRequest, BatchEmailResponse
from app.utils.tone_lexicon import TONE_DEFINITIONS

class EmailGenerator:
    def __init__(self):
        global Groq
        if Groq is None:
            if TYPE_CHECKING:
                # Allow type checkers to resolve the Groq symbol without
                # importing the runtime package at module import time.
                from groq import Groq as _Groq  # pragma: no cover  # type: ignore[reportMissingImports]
                Groq = _Groq
            else:
                try:
                    from groq import Groq as _Groq
                    Groq = _Groq
                except Exception as e:
                    raise ImportError("groq package is not installed. Please install it with: pip install groq") from e
        self.client = Groq(api_key=settings.GROQ_API_KEY)
        
    async def generate_email(self, input_data: EmailInput) -> GeneratedEmail:
        tone_config = TONE_DEFINITIONS.get(input_data.tone.value, TONE_DEFINITIONS["neutral"])
        
        sys_msg = f"You are an expert {input_data.tone.value} email writer. Guidelines: {tone_config['description']}. Use transitions: {', '.join(tone_config['transition_words'])}. Avoid: {', '.join(tone_config['avoid_words'])}."
        
        points_str = '\n'.join(f"- {p}" for p in input_data.key_points)
        user_msg = f"Write a {input_data.email_length} {input_data.tone.value} email.\nTo: {input_data.recipient}\nFrom: {input_data.sender_name}\nPoints:\n{points_str}\nContext: {input_data.context or 'None'}\n\nFormat:\nSubject: [subject]\n[Email body]"
        
        response = self.client.chat.completions.create(
            model=settings.MODEL_NAME,
            messages=[
                {"role": "system", "content": sys_msg},
                {"role": "user", "content": user_msg}
            ],
            max_tokens=settings.MAX_TOKENS,
            temperature=settings.TEMPERATURE
        )
        
        raw_text = response.choices[0].message.content
        
        subject = None
        if "Subject:" in raw_text:
            parts = raw_text.split("Subject:", 1)
            sub_parts = parts[1].split("\n", 1)
            subject = sub_parts[0].strip()
            body = sub_parts[1].strip() if len(sub_parts) > 1 else ""
        else:
            body = raw_text.strip()
            
        covered = [p for p in input_data.key_points if any(w.lower() in body.lower() for w in p.split() if len(w)>3)]
        confidence = len(covered)/len(input_data.key_points) if input_data.key_points else 0.5
        
        return GeneratedEmail(subject=subject, body=body, tone_used=input_data.tone, word_count=len(body.split()), key_points_covered=covered, confidence_score=confidence)

    async def generate_batch_emails(self, request: BatchEmailRequest) -> BatchEmailResponse:
        emails = {}
        for tone in request.tones:
            inp = EmailInput(key_points=request.key_points, recipient=request.recipient, sender_name=request.sender_name, tone=tone, context=request.context)
            emails[tone.value] = await self.generate_email(inp)
        return BatchEmailResponse(emails=emails)

    async def adapt_tone(self, email_text: str, target_tone: ToneType) -> GeneratedEmail:
        tone_config = TONE_DEFINITIONS.get(target_tone.value, TONE_DEFINITIONS["neutral"])
        sys_msg = f"Rewrite this email to be {target_tone.value}. Guidelines: {tone_config['description']}. Keep ALL facts."
        
        response = self.client.chat.completions.create(
            model=settings.MODEL_NAME,
            messages=[
                {"role": "system", "content": sys_msg},
                {"role": "user", "content": email_text}
            ],
            max_tokens=settings.MAX_TOKENS,
            temperature=settings.TEMPERATURE
        )
        body = response.choices[0].message.content.strip()
        
        return GeneratedEmail(body=body, tone_used=target_tone, word_count=len(body.split()), key_points_covered=[], confidence_score=0.9)