import traceback
from fastapi import APIRouter, Depends, HTTPException
from app.models.schemas import EmailInput, GeneratedEmail, BatchEmailRequest, BatchEmailResponse, ToneType
from app.services.generator import EmailGenerator

router = APIRouter(prefix="/api/v1", tags=["email"])

def get_generator():
    return EmailGenerator()

@router.post("/generate", response_model=GeneratedEmail)
async def generate_email(request: EmailInput, generator: EmailGenerator = Depends(get_generator)):
    try:
        return await generator.generate_email(request)
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/generate/batch", response_model=BatchEmailResponse)
async def generate_batch(request: BatchEmailRequest, generator: EmailGenerator = Depends(get_generator)):
    try:
        return await generator.generate_batch_emails(request)
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/adapt-tone", response_model=GeneratedEmail)
async def adapt_tone(request: dict, generator: EmailGenerator = Depends(get_generator)):
    try:
        return await generator.adapt_tone(request["email_text"], ToneType(request["target_tone"]))
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))