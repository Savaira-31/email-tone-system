from typing import List, Optional, Literal
from enum import Enum
from datetime import datetime

try:
    from pydantic import BaseModel, Field  # type: ignore
except ImportError:
    from dataclasses import dataclass, field

    def Field(default=None, **kwargs):  # type: ignore
        if "default_factory" in kwargs:
            return field(default_factory=kwargs["default_factory"])
        return field(default=default)

    class BaseModel:
        def __init__(self, **data):
            for key, value in data.items():
                setattr(self, key, value)

        def dict(self):
            return self.__dict__.copy()

class ToneType(str, Enum):
    FORMAL = "formal"
    FRIENDLY = "friendly"
    URGENT = "urgent"
    APOLOGETIC = "apologetic"
    PERSUASIVE = "persuasive"
    NEUTRAL = "neutral"

class EmailInput(BaseModel):
    key_points: List[str] = Field(..., min_length=1)
    recipient: str
    sender_name: str
    sender_role: Optional[str] = None
    context: Optional[str] = None
    tone: ToneType = ToneType.FORMAL
    include_subject: bool = True
    email_length: Literal["short", "medium", "long"] = "medium"

class GeneratedEmail(BaseModel):
    subject: Optional[str] = None
    body: str
    tone_used: ToneType
    word_count: int
    key_points_covered: List[str]
    generated_at: datetime = Field(default_factory=datetime.now)
    confidence_score: float = Field(ge=0, le=1)

class BatchEmailRequest(BaseModel):
    key_points: List[str]
    recipient: str
    sender_name: str
    tones: List[ToneType]
    context: Optional[str] = None

class BatchEmailResponse(BaseModel):
    emails: dict